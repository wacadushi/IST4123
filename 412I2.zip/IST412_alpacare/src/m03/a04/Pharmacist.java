/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m03.a04;

/**
 *
 * @author myphs
 */
public class Pharmacist extends Person{
    public Pharmacist(){
                this.fName = "";
                this.lName = "";
                this.cell = "";
                this.email = "";
                this.type = "";
        }
}
